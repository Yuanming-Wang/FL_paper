"""Use one C500 context at a time; resume the existing queue after diagnosis."""

from pathlib import Path
import argparse
import hashlib
import json
import os
import signal
import subprocess
import time

root = Path(__file__).resolve().parent
parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--after-method', default='FedPVR')
parser.add_argument('--after-attack', choices=('geiping', 'gi_nas'), default='gi_nas')
parser.add_argument('--candidate', type=Path, default=root / 'controls/hf_candidate.json')
parser.add_argument('--output-name', default='exact_hf_single_validated_profile_c500')
parser.add_argument('--resume-pid', type=int)
args = parser.parse_args()
assert Path(args.output_name).name == args.output_name
state = dict(stage='waiting_for_current_attack', after_method=args.after_method,
             after_attack=args.after_attack, resume_pid=args.resume_pid, started=time.time())


def record():
    temporary = root / 'hf_control_queue_status.json.partial'
    temporary.write_text(json.dumps(state, indent=2))
    temporary.replace(root / 'hf_control_queue_status.json')


try:
    record()
    while True:
        memory = int(Path('/sys/fs/cgroup/memory/memory.usage_in_bytes').read_text())
        # ponytail: a C500 process maps about 16 GiB even for one image;
        # serialize GPU contexts on these 32 GiB VMs; larger VMs permit overlap.
        if (root / 'results' / args.after_method / args.after_attack / 'metrics.json').exists() and memory < 8 * 1024**3:
            break
        time.sleep(10)
    state.update(stage='waiting_for_local_hf_validation')
    record()
    candidate = args.candidate
    while not candidate.exists():
        time.sleep(10)
    control = json.loads(candidate.read_text())
    assert control['passed'] and control['attack'] == 'hf_gradinv'
    source = root / 'safe_FL/system/flcore/attacks/hf_gradinv/attack.py'
    assert hashlib.sha256(source.read_bytes()).hexdigest() == control['implementation_source_sha256']
    config = dict(control['config'])
    config['iterations'] = control.get('requested_iterations', config['iterations'])
    assert config['iterations'] >= control['config']['iterations'] and config['iterations'] % 4 == 0
    output = root / 'diagnostics' / args.output_name
    assert not output.exists()
    output.mkdir(parents=True)
    output.joinpath('attack_source.py').write_bytes(source.read_bytes())
    command = ['/opt/conda/bin/python', '-u', str(root / 'safe_FL/scripts/verify_no_defense.py'),
        '--bundle', str(root / 'diagnostic_inputs/Adap-CTA_gradient_bundle.pt'),
        '--output-dir', str(output), '--attack', 'hf_gradinv', '--sample', '29',
        '--iterations', str(config['iterations']),
        '--hf-input-parameterization', config['input_parameterization']]
    if config['learning_rate_decay']:
        command.append('--hf-lr-decay')
    if config['quantized_gradients']:
        command.append('--hf-quantized')
    assert config['stages'] == 4 and config['tv_weight'] == .0001 and config['gradient_dropout'] == .1
    env = os.environ.copy()
    env.update(MACA_PATH='/opt/maca', LD_LIBRARY_PATH='/opt/maca/ompi/lib:/opt/maca/lib:' + env.get('LD_LIBRARY_PATH', ''),
        OMP_NUM_THREADS='2', OPENBLAS_NUM_THREADS='2', MKL_NUM_THREADS='2',
        MPLCONFIGDIR=str(root / 'cache/matplotlib'))
    with (output / 'run.log').open('w') as log:
        child = subprocess.Popen(command, env=env, cwd=root / 'safe_FL/system',
            stdin=subprocess.DEVNULL, stdout=log, stderr=subprocess.STDOUT)
        state.update(stage='validating_hf', pid=child.pid, output=str(output), command=command)
        record()
        result = child.wait()
    assert result == 0
    report = json.loads((output / 'metrics.json').read_text())
    state.update(stage='complete', passed=report['passed'], finished=time.time())
    record()
except Exception as error:
    state.update(stage='failed', error=repr(error), finished=time.time())
    record()
    raise
finally:
    if args.resume_pid is not None:
        argv = Path('/proc', str(args.resume_pid), 'cmdline').read_bytes().split(b'\0')
        assert str(root / 'safe_FL/scripts/run_privacy_benchmark.py').encode() in argv
        os.kill(args.resume_pid, signal.SIGCONT)
