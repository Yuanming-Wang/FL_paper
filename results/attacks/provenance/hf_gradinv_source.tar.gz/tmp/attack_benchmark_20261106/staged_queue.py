"""Finish captured attacks without re-exporting or interrupting a running GI job."""

import argparse
import json
import os
from pathlib import Path
import subprocess
import tempfile
import time


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--methods', nargs=2, required=True)
    parser.add_argument('--existing-gi-pid', type=int, required=True)
    parser.add_argument('--early-hf', help='Run this method HF first after the existing GI finishes')
    args = parser.parse_args()
    assert args.early_hf is None or args.early_hf in args.methods
    root = Path(__file__).resolve().parent
    status = dict(stage='waiting_for_existing_gi', methods=args.methods,
                  existing_gi_pid=args.existing_gi_pid, started=time.time())

    def record():
        with tempfile.NamedTemporaryFile(mode='w', dir=root, delete=False) as handle:
            json.dump(status, handle, indent=2)
            temporary = Path(handle.name)
        temporary.replace(root / 'group_status.json')

    env = os.environ.copy()
    env.update(MACA_PATH='/opt/maca',
        LD_LIBRARY_PATH='/opt/maca/ompi/lib:/opt/maca/lib:' + env.get('LD_LIBRARY_PATH', ''),
        OMP_NUM_THREADS='2', OPENBLAS_NUM_THREADS='2', MKL_NUM_THREADS='2',
        MPLCONFIGDIR=str(root / 'cache/matplotlib'))

    def run(method, attacks, hf_iterations=None):
        status.update(stage='attacking', algorithm=method, attacks=attacks)
        record()
        command = ['/opt/conda/bin/python', '-u',
            str(root / 'safe_FL/scripts/run_privacy_benchmark.py'),
            '--method', method, '--captures', str(root / 'captures'),
            '--output-root', str(root / 'results'),
            '--geiping-control', str(root / 'controls/geiping.json'),
            '--ginas-control', str(root / 'controls/gi_nas.json'), '--attacks', *attacks]
        if hf_iterations is not None:
            command += ['--hf-iterations', str(hf_iterations),
                        '--hf-control', str(root / 'controls/hf_gradinv.json')]
        subprocess.run(command, env=env, cwd=root / 'safe_FL/system',
                       stdin=subprocess.DEVNULL, check=True)

    try:
        record()
        report = root / 'results' / args.methods[0] / 'gi_nas/metrics.json'
        while not report.exists():
            process = Path('/proc') / str(args.existing_gi_pid)
            if not process.exists() or process.joinpath('stat').read_text().split()[2] == 'Z':
                raise RuntimeError('Existing GI process exited before writing its report')
            time.sleep(10)
        if args.early_hf is not None:
            validation = json.loads((root / 'controls/hf_gradinv.json').read_text())
            assert validation['passed']
            run(args.early_hf, ['hf_gradinv'], validation['config']['iterations'])
        for method in args.methods:
            run(method, ['geiping', 'gi_nas'])
        status.update(stage='waiting_for_hf_validation')
        record()
        control = root / 'controls/hf_gradinv.json'
        while not control.exists():
            time.sleep(15)
        validation = json.loads(control.read_text())
        assert validation['passed'] and validation['attack'] == 'hf_gradinv'
        config = validation['config']
        for method in args.methods:
            run(method, ['hf_gradinv'], config['iterations'])
            run(method, ['geiping', 'gi_nas', 'hf_gradinv'], config['iterations'])
        status.update(stage='complete', finished=time.time())
        record()
    except Exception as error:
        status.update(stage='failed', error=repr(error), finished=time.time())
        record()
        raise


if __name__ == '__main__':
    main()
